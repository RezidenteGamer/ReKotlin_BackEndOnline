package com.reKotlin.portalAcademico

import org.springframework.boot.autoconfigure.SpringBootApplication
import org.springframework.boot.runApplication

@SpringBootApplication
class PortalAcademicoApplication

fun main(args: Array<String>) {
	runApplication<PortalAcademicoApplication>(*args)
}
