package com.reKotlin.portalAcademico.modelo

import jakarta.persistence.*

@Entity
class Turma(
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    val id: Long? = null,

    @Column(nullable = false)
    var nome: String,

    var descricao: String,

    @ManyToOne(fetch = FetchType.LAZY) // Muitas turmas para um professor
    @JoinColumn(name = "professor_id")
    val professor: Professor,

    @ManyToMany
    @JoinTable( // Tabela de ligação para o relacionamento Muitos-para-Muitos
        name = "turma_academicos",
        joinColumns = [JoinColumn(name = "turma_id")],
        inverseJoinColumns = [JoinColumn(name = "academico_id")]
    )
    val academicosMatriculados: MutableList<Academico> = mutableListOf()
)