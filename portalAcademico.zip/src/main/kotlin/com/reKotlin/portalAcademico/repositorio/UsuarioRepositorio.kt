package com.reKotlin.portalAcademico.repositorio

import com.reKotlin.portalAcademico.modelo.Usuario
import org.springframework.data.jpa.repository.JpaRepository
import org.springframework.stereotype.Repository

@Repository
interface UsuarioRepositorio : JpaRepository<Usuario, Long> {
    // Para o login (funcionalidade extra)
    fun findByEmail(email: String): Usuario?
}