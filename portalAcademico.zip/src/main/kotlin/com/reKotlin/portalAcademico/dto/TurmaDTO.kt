package com.reKotlin.portalAcademico.dto

import jakarta.validation.constraints.NotEmpty
import jakarta.validation.constraints.NotNull

// DTO para criar ou atualizar uma turma
data class TurmaRequestDTO(
    @field:NotEmpty(message = "O nome não pode ser vazio")
    val nome: String,

    val descricao: String,

    @field:NotNull(message = "O ID do professor é obrigatório")
    val professorId: Long
)

// DTO para exibir dados da turma
data class TurmaResponseDTO(
    val id: Long,
    val nome: String,
    val descricao: String,
    val nomeProfessor: String,
    val quantidadeAlunos: Int
)