package com.reKotlin.portalAcademico

import org.junit.jupiter.api.Test
import org.springframework.boot.test.context.SpringBootTest

@SpringBootTest
class PortalAcademicoApplicationTests {

	@Test
	fun contextLoads() {
	}

}
